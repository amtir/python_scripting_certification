#List
list=[1,2,"Python","Android"]
print(list)

list[2]="Data Science"
print(list)

#Tuple
tup=(1,2,3,"Data Science")
print(tup)

tup[1]="Python"
print(tup)

