str1='Welcome'
str2="to"
str3="""Edureka"""

print(str1)
print(str2)
print(str3)

string="Python"
print(string)
print(len(string))
print(string[1:3])
print('t' in string)



print("Welcome to %s"%("Python"))
print("My name is %s and my age is %d"%("Annie",22))

str='edureka'
print(str.capitalize())
print(str.count("ka",0,len(str)))

s=str.encode('utf-8','strict')
print(s)

print(max(str))
print(min(str))
print(str.replace('e','--E--',1))
print(str.upper())
print(str.index('k'))

str1="Happy Learning"

print(str1[::-1])

print(str1[2:7])

print(str1.find('L'))

str2="Welcome to Edureka"

print(str1+str2)

print(str1*2)