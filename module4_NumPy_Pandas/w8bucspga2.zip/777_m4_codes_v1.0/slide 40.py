import numpy as np
arr=np.arange(20)
print(arr[2:])

import numpy as np
arr=np.arange(20)
print(arr[:15])

