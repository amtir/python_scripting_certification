import numpy as np
arr=np.arange(20)
arr_slice=slice(1,10,2)
element=arr[6]
print(arr[arr_slice])
