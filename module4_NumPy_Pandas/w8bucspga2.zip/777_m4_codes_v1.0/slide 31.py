import numpy as np
arr = np.arange(10, 100)
print(arr)